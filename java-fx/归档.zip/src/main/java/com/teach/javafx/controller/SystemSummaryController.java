package com.teach.javafx.controller;

public class SystemSummaryController {
}
