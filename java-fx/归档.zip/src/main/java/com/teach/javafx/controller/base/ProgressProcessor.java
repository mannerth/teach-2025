package com.teach.javafx.controller.base;

public interface ProgressProcessor {
    void step(int pos);
}
