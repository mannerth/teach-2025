package com.teach.javafx.controller;

public interface HonorEditorOpener {
    void hasSaved();
}
